# OmniEdit AI

A responsive React + Express creative workspace with:
- AI image generation using the OpenAI Images API (`gpt-image-2.5-sunburst`)
- AI captions, hashtags, short scripts and content-idea briefs using the Responses API
- Local video preview, trim-range selection, preview filters, WebM export in supported browsers
- AI analysis of a captured video frame
- Local recent-creation history

## Requirements
- Node.js 20+
- An OpenAI API key with access to the selected image and text models
- API billing/credits enabled for paid API calls

## Run locally
1. Extract the project.
2. Open a terminal in the `omni-edit` folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Create your environment file:
   ```bash
   cp .env.example .env
   ```
   On Windows, copy `.env.example` to `.env`.
5. Put your API key in `.env`:
   ```env
   OPENAI_API_KEY=your_real_key
   OPENAI_TEXT_MODEL=gpt-5.4
   PORT=8787
   ```
6. Start the app:
   ```bash
   npm run dev
   ```
7. Open `http://localhost:5173`.

For a production build, run `npm run build`, then `npm start`. The Express server serves the built frontend.

## Important security notes
- Keep `OPENAI_API_KEY` only in `.env` on the server. Never put it in React code, browser storage, or a public repository.
- Add authentication, per-user quotas, billing controls and persistent storage before opening this to the public.
- API calls may cost money. The app has basic request rate limiting, but it is not a full production billing system.
- The text model can be changed with `OPENAI_TEXT_MODEL` if your API account does not have access to the default.

## Video features and current API status
The video workspace works locally in the browser: preview, range selection, basic CSS preview filters, and WebM export using browser MediaRecorder support. Frame analysis sends one captured frame to the configured text/vision model.

Do not assume OpenAI video generation is available. OpenAI's official deprecation notice says the Videos API and Sora 2 API models were removed on 24 September 2026. This project therefore does not include a fake "AI video generation" button or claim that the OpenAI video API is live. A separate currently supported video provider can be integrated later through a server-side adapter.

## Before launching publicly
This is a runnable starter product, not a finished SaaS business. Add sign-in, a database, secure cloud media storage, abuse controls, subscription/payment integration, usage metering, privacy/terms pages, backups, monitoring and deployment secrets. Do not advertise "unlimited" generations unless your provider costs and quotas support that promise.

## Android APK

See [README-ANDROID.md](README-ANDROID.md) for building a personal Android APK with GitHub Actions. Note that the AI backend must be hosted separately for cloud AI features to work in the APK.
