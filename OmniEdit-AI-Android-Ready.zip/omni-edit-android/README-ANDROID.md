# Build OmniEdit AI for Android (using GitHub, no computer required)

This project includes a GitHub Actions workflow that builds a debug APK in GitHub's cloud.

## Important about AI features

The Android APK contains the OmniEdit web interface and local browser-based video tools. The Express/OpenAI backend is a separate server and is **not** bundled into the APK. Until you host that backend and set `VITE_API_BASE_URL` to its HTTPS address, AI image generation, writing, and frame analysis will not work in the installed APK. Never put an OpenAI API key in frontend code or in the APK.

## Steps

1. On GitHub, create a new repository named `omni-edit-ai`. Keep it private if you prefer.
2. Upload the contents of this project folder to the repository (not the enclosing folder). Make sure `.github/workflows/android-apk.yml` is included. On GitHub's upload page, hidden files may need to be included; verify `.github/workflows/android-apk.yml` exists after upload.
3. Open the repository's **Actions** tab. If GitHub asks to enable workflows, enable them.
4. Select **Build OmniEdit AI Android APK** and tap **Run workflow** (or wait for the first push workflow to finish).
5. When the run finishes with a green check, open that run and scroll to **Artifacts**.
6. Download `OmniEdit-AI-debug-apk`, extract the ZIP on your phone, then tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/files app. Only install the APK built from your own repository.

## App identity

- App name: OmniEdit AI
- Android application ID: `com.omniedit.ai`

This workflow creates a debug APK for personal testing, not a Play Store release-signed APK.
