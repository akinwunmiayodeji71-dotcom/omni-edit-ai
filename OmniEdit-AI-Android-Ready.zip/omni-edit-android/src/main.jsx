import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  WandSparkles, Image as ImageIcon, Video, Captions, TrendingUp, LayoutDashboard,
  Settings, Download, Sparkles, ArrowRight, Upload, Play, Pause, Scissors,
  RefreshCw, Copy, Check, Menu, X, Clapperboard, Zap, CircleHelp, ExternalLink
} from "lucide-react";
import "./styles.css";

const nav = [
  ["dashboard", "Overview", LayoutDashboard],
  ["image", "Image studio", ImageIcon],
  ["video", "Video studio", Video],
  ["captions", "Captions & scripts", Captions],
  ["trends", "Content ideas", TrendingUp]
];

const API_BASE = (import.meta.env.VITE_API_BASE_URL || "").replace(/\/$/, "");
const apiUrl = (path) => `${API_BASE}${path}`;

async function api(path, body) {
  const response = await fetch(apiUrl(path), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

function App() {
  const [page, setPage] = useState("dashboard");
  const [mobileNav, setMobileNav] = useState(false);
  const [aiReady, setAiReady] = useState(false);
  const [toast, setToast] = useState("");
  const [history, setHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem("omni-history") || "[]"); } catch { return []; }
  });
  useEffect(() => {
    fetch(apiUrl("/api/health")).then(r => r.json()).then(d => setAiReady(d.aiConfigured)).catch(() => setAiReady(false));
  }, []);
  useEffect(() => localStorage.setItem("omni-history", JSON.stringify(history.slice(0, 12))), [history]);
  const notify = (msg) => { setToast(msg); window.clearTimeout(notify.timer); notify.timer = window.setTimeout(() => setToast(""), 3200); };
  const addHistory = (item) => setHistory(old => [{ ...item, id: Date.now() }, ...old].slice(0, 12));

  const renderPage = () => {
    if (page === "image") return <ImageStudio addHistory={addHistory} notify={notify} />;
    if (page === "video") return <VideoStudio notify={notify} />;
    if (page === "captions") return <Writer mode="caption" title="Captions & scripts" subtitle="Write platform-ready copy, hooks and short-form scripts." />;
    if (page === "trends") return <Writer mode="trends" title="Content ideas & trend lab" subtitle="Build content experiments and discover angles worth testing." />;
    return <Dashboard setPage={setPage} history={history} aiReady={aiReady} />;
  };

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark"><WandSparkles size={21}/></div><span>omni<span className="brand-light">edit</span><sup>AI</sup></span>
        <button className="icon-btn close-nav" onClick={() => setMobileNav(false)}><X size={18}/></button>
      </div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(([id, label, Icon]) => <button key={id} className={`nav-link ${page === id ? "selected" : ""}`} onClick={() => { setPage(id); setMobileNav(false); }}><Icon size={18}/><span>{label}</span>{id === "image" && <span className="nav-dot"/>}</button>)}</nav>
      <div className="sidebar-bottom">
        <div className="upgrade-card"><div className="upgrade-icon"><Zap size={16}/></div><b>Make more with AI</b><p>Connect your AI key to unlock real generation tools.</p><button onClick={() => notify("Add your API key to the .env file to activate AI.")}>Setup AI <ArrowRight size={14}/></button></div>
        <button className="nav-link muted" onClick={() => notify("Settings are managed in your project .env file.")}><Settings size={18}/>Settings</button>
        <div className="profile"><div className="avatar">O</div><div><b>OmniEdit Studio</b><small>Personal workspace</small></div><span className={`status ${aiReady ? "online" : ""}`} title={aiReady ? "AI connected" : "AI not configured"}/></div>
      </div>
    </aside>
    {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)}/>}
    <main className="main">
      <header className="topbar">
        <button className="icon-btn menu-btn" onClick={() => setMobileNav(true)}><Menu size={20}/></button>
        <div className="breadcrumb">Workspace <span>/</span> <b>{nav.find(n => n[0] === page)?.[1] || "Overview"}</b></div>
        <div className="top-actions"><span className={`connection ${aiReady ? "connected" : ""}`}><i/>{aiReady ? "AI connected" : "AI not configured"}</span><div className="avatar small">O</div></div>
      </header>
      <div className="page-content">{renderPage()}</div>
      <footer className="footer"><span>OMNIEDIT AI</span><span>Creative tools, all in one place.</span><a href="https://platform.openai.com/api-keys" target="_blank" rel="noreferrer">API setup <ExternalLink size={12}/></a></footer>
    </main>
    {toast && <div className="toast"><Sparkles size={16}/>{toast}</div>}
  </div>;
}

function PageHeading({eyebrow, title, subtitle, right}) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{right}</div>;
}

function Dashboard({setPage, history, aiReady}) {
  return <>
    <section className="hero">
      <div className="hero-glow"/>
      <div className="hero-copy"><div className="eyebrow light">YOUR CREATIVE COMMAND CENTER</div><h1>Make something<br/><em>remarkable.</em></h1><p>Turn ideas into images, videos and scroll-stopping content with one creative workspace.</p><button className="btn primary" onClick={() => setPage("image")}>Start creating <ArrowRight size={16}/></button></div>
      <div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="art-core"><WandSparkles size={48}/></div><div className="float-chip chip-a"><ImageIcon size={16}/> Image AI</div><div className="float-chip chip-b"><Captions size={16}/> Smart captions</div><div className="float-chip chip-c"><Video size={16}/> Video tools</div></div>
    </section>
    <div className="section-title"><div><h2>Creative tools</h2><p>Pick a tool and bring your next idea to life.</p></div><span className="tool-count">05 TOOLS</span></div>
    <div className="tool-grid">
      <ToolCard icon={ImageIcon} tone="violet" title="AI image studio" desc="Generate original visuals from a text prompt." tag="IMAGE GENERATION" onClick={() => setPage("image")}/>
      <ToolCard icon={Video} tone="blue" title="Video studio" desc="Preview, trim and inspect your own video clips." tag="VIDEO WORKSPACE" onClick={() => setPage("video")}/>
      <ToolCard icon={Captions} tone="orange" title="Caption writer" desc="Create captions, hooks, hashtags and scripts." tag="COPYWRITING" onClick={() => setPage("captions")}/>
      <ToolCard icon={TrendingUp} tone="green" title="Content ideas lab" desc="Turn a niche into practical experiments to test." tag="IDEATION" onClick={() => setPage("trends")}/>
    </div>
    <div className="section-title recent-title"><div><h2>Recent creations</h2><p>Your latest work on this device.</p></div></div>
    {history.length ? <div className="history-list">{history.map(item => <div className="history-row" key={item.id}><div className="history-icon"><Sparkles size={17}/></div><div><b>{item.title}</b><small>{item.type} · {new Date(item.id).toLocaleString()}</small></div><span className="history-status">Saved locally</span></div>)}</div> : <div className="empty-state"><div className="empty-icon"><Clapperboard size={24}/></div><b>Your creative history starts here</b><p>Generate an image or create some content to see it here.</p></div>}
    <div className={`setup-note ${aiReady ? "ready" : ""}`}><div className="setup-symbol"><Zap size={18}/></div><div><b>{aiReady ? "AI connection is ready" : "One setup step to activate AI"}</b><p>{aiReady ? "Your server has an API key configured. Image and writing tools can connect." : "Add your OpenAI API key to the server .env file. Your key stays private and is never sent to the browser."}</p></div><span>{aiReady ? "CONNECTED" : "SETUP REQUIRED"}</span></div>
  </>;
}

function ToolCard({icon: Icon, tone, title, desc, tag, onClick}) {
  return <button className="tool-card" onClick={onClick}><div className={`tool-icon ${tone}`}><Icon size={21}/></div><div className="tool-tag">{tag}</div><h3>{title}</h3><p>{desc}</p><div className="tool-link">Open tool <ArrowRight size={15}/></div></button>;
}

function ImageStudio({addHistory, notify}) {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("Cinematic");
  const [ratio, setRatio] = useState("1:1");
  const [quality, setQuality] = useState("medium");
  const [loading, setLoading] = useState(false);
  const [image, setImage] = useState("");
  const [error, setError] = useState("");
  const generate = async () => {
    if (!prompt.trim()) return setError("Describe the image you want to create.");
    setLoading(true); setError("");
    try {
      const data = await api("/api/generate-image", {prompt, style, ratio, quality});
      setImage(data.image); addHistory({title: prompt.slice(0, 70), type: "AI image"});
    } catch(e) { setError(e.message); }
    finally { setLoading(false); }
  };
  return <>
    <PageHeading eyebrow="IMAGE WORKSPACE" title="AI image studio" subtitle="Create original artwork, campaign visuals and concepts from a simple description." right={<span className="beta-pill"><Sparkles size={13}/> GPT IMAGE</span>}/>
    <div className="studio-layout">
      <section className="panel form-panel">
        <div className="panel-heading"><div><span className="step-label">01 / PROMPT</span><h2>Describe your vision</h2></div><span className="panel-icon"><WandSparkles size={18}/></span></div>
        <label htmlFor="img-prompt">Image description</label>
        <textarea id="img-prompt" className="prompt-box" value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="A premium product photo of a glass perfume bottle on a dark stone pedestal, soft golden studio lighting..." rows={6}/>
        <div className="label-row"><label>Visual style</label><span>Choose a direction</span></div>
        <div className="style-options">{["Cinematic","Photorealistic","Editorial","3D render","Anime","Watercolor"].map(s => <button key={s} className={style === s ? "chosen" : ""} onClick={() => setStyle(s)}>{s}</button>)}</div>
        <div className="two-fields"><div><label>Aspect ratio</label><select value={ratio} onChange={e => setRatio(e.target.value)}><option>1:1</option><option>16:9</option><option>9:16</option></select></div><div><label>Quality</label><select value={quality} onChange={e => setQuality(e.target.value)}><option value="medium">Standard</option><option value="high">High</option></select></div></div>
        {error && <div className="error-msg">{error}</div>}
        <button className="btn primary full" disabled={loading} onClick={generate}>{loading ? <><span className="spinner"/> Creating your image...</> : <><Sparkles size={16}/> Generate image</>}</button>
        <p className="micro-copy">Image generation uses your API account and may incur usage charges.</p>
      </section>
      <section className="panel result-panel"><div className="panel-heading"><div><span className="step-label">02 / CANVAS</span><h2>Your creation</h2></div><span className="canvas-state">{loading ? "GENERATING" : image ? "COMPLETE" : "AWAITING PROMPT"}</span></div>
        <div className={`image-canvas ${image ? "has-image" : ""}`}>{loading ? <div className="loading-view"><div className="big-spinner"/><b>Creating your visual</b><p>Good things take a moment. Keep this tab open.</p></div> : image ? <img src={image} alt="AI generated artwork"/> : <div className="canvas-placeholder"><div className="placeholder-art"><ImageIcon size={38}/><Sparkles size={18}/></div><b>Your canvas is waiting</b><p>Your generated image will appear here.</p></div>}</div>
        {image && <div className="result-actions"><a className="btn primary" href={image} download="omni-edit-creation.png"><Download size={16}/> Download PNG</a><button className="btn secondary" onClick={() => {setImage(""); notify("Canvas cleared.");}}><RefreshCw size={15}/> New creation</button></div>}
      </section>
    </div>
  </>;
}

function VideoStudio({notify}) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const fileRef = useRef(null);
  const [src, setSrc] = useState("");
  const [fileName, setFileName] = useState("");
  const [duration, setDuration] = useState(0);
  const [start, setStart] = useState(0);
  const [end, setEnd] = useState(0);
  const [filter, setFilter] = useState("none");
  const [analysis, setAnalysis] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [playing, setPlaying] = useState(false);
  useEffect(() => () => { if (src) URL.revokeObjectURL(src); }, [src]);
  const loadFile = (file) => {
    if (!file) return;
    if (!file.type.startsWith("video/")) return setError("Please choose a video file.");
    if (src) URL.revokeObjectURL(src);
    setSrc(URL.createObjectURL(file)); setFileName(file.name); setAnalysis(""); setError("");
  };
  const meta = () => { const d = videoRef.current?.duration || 0; setDuration(d); setEnd(d); setStart(0); };
  const fmt = (v) => `${Math.floor(v/60)}:${String(Math.floor(v%60)).padStart(2,"0")}`;
  const capture = async () => {
    const video = videoRef.current, canvas = canvasRef.current;
    if (!video || !canvas || !video.videoWidth) return;
    canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext("2d").drawImage(video, 0, 0, canvas.width, canvas.height);
    setBusy(true); setError("");
    try {
      const data = await api("/api/analyze-frame", {image: canvas.toDataURL("image/jpeg", .82)});
      setAnalysis(data.text);
    } catch(e) { setError(e.message); }
    finally { setBusy(false); }
  };
  const exportClip = async () => {
    const video = videoRef.current;
    if (!video || end <= start) return setError("Set an end time later than the start time.");
    setError("");
    try {
      const stream = canvasRef.current.captureStream(30);
      const sourceStream = video.captureStream?.();
      sourceStream?.getAudioTracks().forEach(t => stream.addTrack(t));
      const recorder = new MediaRecorder(stream, {mimeType: MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm"});
      const chunks = [];
      recorder.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunks, {type:"video/webm"});
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a"); a.href = url; a.download = "omni-edit-trimmed.webm"; a.click();
        setTimeout(() => URL.revokeObjectURL(url), 3000);
        notify("Your trimmed WebM clip has been exported.");
      };
      const canvas = canvasRef.current, ctx = canvas.getContext("2d");
      canvas.width = video.videoWidth; canvas.height = video.videoHeight;
      video.currentTime = start;
      await new Promise(resolve => video.addEventListener("seeked", resolve, {once:true}));
      const draw = () => { if (!video.paused && !video.ended) { ctx.filter = filter; ctx.drawImage(video,0,0,canvas.width,canvas.height); requestAnimationFrame(draw); } };
      recorder.start(); video.play(); draw();
      const stopAt = () => { if (video.currentTime >= end) { video.pause(); recorder.stop(); video.removeEventListener("timeupdate", stopAt); } };
      video.addEventListener("timeupdate", stopAt);
    } catch(e) { setError("Clip export is not supported by this browser. Try Chrome or Edge on desktop."); }
  };
  return <>
    <PageHeading eyebrow="VIDEO WORKSPACE" title="Video studio" subtitle="Bring in a clip, preview the look, trim a section and ask AI to inspect a frame." right={<span className="beta-pill"><Video size={13}/> LOCAL EDITOR</span>}/>
    <div className="video-layout">
      <section className="panel video-main">
        <div className="panel-heading"><div><span className="step-label">01 / SOURCE</span><h2>Video preview</h2></div><button className="btn secondary compact" onClick={() => fileRef.current?.click()}><Upload size={15}/> Upload video</button><input ref={fileRef} hidden type="file" accept="video/*" onChange={e => loadFile(e.target.files?.[0])}/></div>
        {!src ? <button className="drop-zone" onClick={() => fileRef.current?.click()}><div className="drop-icon"><Upload size={23}/></div><b>Drop a video here or browse files</b><span>MP4, WebM and other browser-supported video formats</span></button> :
          <><div className="video-frame"><video ref={videoRef} src={src} controls onLoadedMetadata={meta} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} style={{filter: filter}}/><canvas ref={canvasRef} className="hidden-canvas"/></div><div className="video-meta"><b>{fileName}</b><span>{fmt(duration)} total duration</span></div>
          <div className="timeline"><div className="timeline-head"><label><Scissors size={14}/> TRIM RANGE</label><span>{fmt(start)} — {fmt(end)}</span></div><div className="range-row"><div><small>START</small><input type="range" min="0" max={Math.max(duration,0.1)} step=".1" value={start} onChange={e => setStart(Math.min(Number(e.target.value), end-.1))}/></div><div><small>END</small><input type="range" min="0" max={Math.max(duration,0.1)} step=".1" value={end} onChange={e => setEnd(Math.max(Number(e.target.value), start+.1))}/></div></div><div className="range-labels"><span>0:00</span><span>{fmt(duration)}</span></div></div>
          <div className="filter-row"><label>PREVIEW LOOK</label>{[["none","Original"],["grayscale(1)","B&W"],["sepia(.65)","Warm"],["contrast(1.2) saturate(1.3)","Vivid"]].map(([v,l])=><button key={v} className={filter===v?"active":""} onClick={()=>setFilter(v)}>{l}</button>)}</div>
          <div className="video-actions"><button className="btn secondary" onClick={() => {videoRef.current.currentTime=start; videoRef.current.play();}}><Play size={15}/> Play selection</button><button className="btn primary" onClick={exportClip}><Download size={15}/> Export trimmed clip</button></div></>}
        {error && <div className="error-msg">{error}</div>}
        <p className="micro-copy">Trimming exports a WebM clip in supported browsers. Preview filters are applied to the export.</p>
      </section>
      <aside className="panel analysis-panel"><div className="panel-heading"><div><span className="step-label">02 / AI ASSISTANT</span><h2>Frame analysis</h2></div><span className="panel-icon"><Sparkles size={17}/></span></div><div className="analysis-intro"><div className="analysis-graphic"><Sparkles size={23}/></div><b>Understand your scene</b><p>Pause the video on a frame you want to inspect, then ask AI for visual feedback and editing suggestions.</p></div><button className="btn primary full" disabled={!src || busy} onClick={capture}>{busy ? <><span className="spinner"/> Analyzing frame...</> : <><WandSparkles size={16}/> Analyze current frame</>}</button>{analysis && <div className="analysis-result"><div className="result-heading">AI FRAME NOTES <button className="icon-btn" onClick={() => navigator.clipboard.writeText(analysis).then(()=>notify("Analysis copied."))}><Copy size={14}/></button></div><p>{analysis}</p></div>}<div className="tip-box"><CircleHelp size={16}/><p><b>Tip</b> Pause on a clear frame with the subject visible for more useful feedback.</p></div></aside>
    </div>
  </>;
}

function Writer({mode, title, subtitle}) {
  const [topic, setTopic] = useState("");
  const [platform, setPlatform] = useState("Instagram");
  const [kind, setKind] = useState(mode === "trends" ? "ideas" : "caption");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const run = async () => {
    if (!topic.trim()) return setError("Add a topic or a short description first.");
    setLoading(true); setError(""); setCopied(false);
    try { const d = await api("/api/write", {topic, platform, mode: kind}); setResult(d.text); }
    catch(e) { setError(e.message); }
    finally { setLoading(false); }
  };
  const copy = () => navigator.clipboard.writeText(result).then(() => {setCopied(true); setTimeout(()=>setCopied(false),1800);});
  const modes = mode === "trends" ? [["ideas","Content ideas"],["trends","Trend hypotheses"],["hashtags","Hashtag sets"]] : [["caption","Captions"],["script","Video script"],["hashtags","Hashtags"]];
  return <>
    <PageHeading eyebrow={mode === "trends" ? "IDEATION WORKSPACE" : "AI WRITING WORKSPACE"} title={title} subtitle={subtitle}/>
    <div className="writer-layout">
      <section className="panel writer-form"><div className="panel-heading"><div><span className="step-label">01 / BRIEF</span><h2>What are we creating?</h2></div><span className="panel-icon"><Captions size={18}/></span></div>
        <label htmlFor="topic">Topic or brand brief</label><textarea id="topic" className="prompt-box" rows={6} value={topic} onChange={e=>setTopic(e.target.value)} placeholder="e.g. A new natural skincare line for busy young professionals..."/>
        <div className="two-fields"><div><label>Platform</label><select value={platform} onChange={e=>setPlatform(e.target.value)}>{["Instagram","TikTok","YouTube","Facebook","LinkedIn","X"].map(x=><option key={x}>{x}</option>)}</select></div><div><label>Output type</label><select value={kind} onChange={e=>setKind(e.target.value)}>{modes.map(([v,l])=><option value={v} key={v}>{l}</option>)}</select></div></div>
        {error && <div className="error-msg">{error}</div>}
        <button className="btn primary full" disabled={loading} onClick={run}>{loading ? <><span className="spinner"/> Working on it...</> : <><Sparkles size={16}/> Generate content</>}</button>
        <p className="micro-copy">AI-generated suggestions are starting points. Review facts and platform rules before publishing.</p>
      </section>
      <section className="panel writer-output"><div className="panel-heading"><div><span className="step-label">02 / OUTPUT</span><h2>Your content</h2></div>{result && <button className="btn secondary compact" onClick={copy}>{copied?<Check size={14}/>:<Copy size={14}/>} {copied?"Copied":"Copy text"}</button>}</div>
        {loading ? <div className="loading-view"><div className="big-spinner"/><b>Putting ideas together</b><p>Your result will appear here shortly.</p></div> : result ? <pre className="generated-text">{result}</pre> : <div className="canvas-placeholder writer-placeholder"><div className="placeholder-art"><Captions size={36}/></div><b>Good content starts with a brief</b><p>Describe your idea and choose the output you need.</p></div>}
      </section>
    </div>
  </>;
}

createRoot(document.getElementById("root")).render(<App/>);