import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = Number(process.env.PORT || 8787);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(express.json({ limit: "18mb" }));
app.use("/api", rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));

function requireAI(req, res, next) {
  if (!client) return res.status(503).json({ error: "AI is not configured yet. Add OPENAI_API_KEY to your .env file and restart the server." });
  next();
}
function clean(value, max = 6000) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(client) });
});

app.post("/api/generate-image", requireAI, async (req, res) => {
  try {
    const prompt = clean(req.body.prompt);
    if (!prompt) return res.status(400).json({ error: "Enter an image description first." });
    const style = clean(req.body.style, 80) || "Cinematic";
    const ratio = clean(req.body.ratio, 20) || "1:1";
    const size = ratio === "16:9" ? "1536x864" : ratio === "9:16" ? "864x1536" : "1024x1024";
    const result = await client.images.generate({
      model: "gpt-image-2.5-sunburst",
      prompt: `${prompt}\nVisual direction: ${style}.`,
      size,
      quality: req.body.quality === "high" ? "high" : "medium",
      output_format: "png",
      n: 1
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error("The image service returned no image.");
    res.json({ image: `data:image/png;base64,${b64}` });
  } catch (error) {
    console.error("Image generation:", error);
    res.status(500).json({ error: error?.message || "Image generation failed." });
  }
});

app.post("/api/write", requireAI, async (req, res) => {
  try {
    const topic = clean(req.body.topic, 3000);
    if (!topic) return res.status(400).json({ error: "Enter a topic or describe what you need." });
    const mode = clean(req.body.mode, 40) || "caption";
    const platform = clean(req.body.platform, 40) || "Instagram";
    const instructions = {
      caption: `Write 3 engaging ${platform} captions for this topic. Include a clear hook and a natural call to action. Add relevant hashtags separately.`,
      hashtags: `Create a balanced set of relevant ${platform} hashtags for this topic. Group them into broad, niche, and community tags. Avoid claiming they are trending unless verified.`,
      ideas: `Create 10 original short-form content ideas for this topic and ${platform}. For each, give a hook and a one-line execution idea.`,
      script: `Write a concise 30-45 second vertical video script for this topic. Include a strong first 2-second hook, spoken lines, suggested visuals, and a CTA.`,
      trends: `Create a trend research brief for this topic: likely audience interests, content angles to test, 5 experiment ideas, and metrics to watch. Clearly label these as hypotheses, not live trend data.`
    };
    const response = await client.responses.create({
      model: process.env.OPENAI_TEXT_MODEL || "gpt-5.4",
      instructions: "You are OmniEdit, a practical social content strategist. Be specific, useful, concise, and honest. Do not invent live analytics or claim to have checked social platforms.",
      input: `${instructions[mode] || instructions.caption}\n\nTopic: ${topic}`,
    });
    res.json({ text: response.output_text || "No text was returned." });
  } catch (error) {
    console.error("Writing assistant:", error);
    res.status(500).json({ error: error?.message || "The writing assistant failed." });
  }
});

app.post("/api/analyze-frame", requireAI, async (req, res) => {
  try {
    const image = clean(req.body.image, 15_000_000);
    if (!image.startsWith("data:image/")) return res.status(400).json({ error: "Choose a video and capture a frame first." });
    const response = await client.responses.create({
      model: process.env.OPENAI_TEXT_MODEL || "gpt-5.4",
      instructions: "You are a video editor and visual analyst. Describe only what is visible. Give a concise scene summary, composition and lighting notes, possible improvements, and 3 editing suggestions.",
      input: [{
        role: "user",
        content: [
          { type: "input_text", text: "Analyze this frame from my video." },
          { type: "input_image", image_url: image }
        ]
      }]
    });
    res.json({ text: response.output_text || "No analysis was returned." });
  } catch (error) {
    console.error("Frame analysis:", error);
    res.status(500).json({ error: error?.message || "Frame analysis failed." });
  }
});

// Serve the production build when one exists.
const dist = path.join(__dirname, "dist");
app.use(express.static(dist));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(dist, "index.html"), (err) => {
    if (err) res.status(404).send("Build the frontend first with npm run build.");
  });
});

app.listen(port, () => console.log(`OmniEdit server running on http://localhost:${port}`));